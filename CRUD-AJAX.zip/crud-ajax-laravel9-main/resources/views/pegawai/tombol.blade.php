<a href='#' data-id="{{ $data->id }}" class="btn btn-warning btn-sm tombol-edit">Edit</a>
<a href='#' data-id="{{ $data->id }}" class="btn btn-danger btn-sm tombol-del">Del</a>
