<div class="panel panel-default text-center">
    <div class="panel-heading">
        <h3 class="panel-title">Donations Appreciated</h3>
    </div>
    <div class="panel-body">
        <p>
            {!! App\Services\Donate::quote() !!}
        </p>
    </div>
</div>
