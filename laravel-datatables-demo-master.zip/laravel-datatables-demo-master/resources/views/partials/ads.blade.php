<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- DT Ads -->
<ins class="adsbygoogle"
     style="{{$style}}"
     data-ad-client="{{$client or env('ADS_CLIENT')}}"
     data-ad-slot="{{$slot}}"
     data-ad-format="{{$format}}"></ins>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
</script>
