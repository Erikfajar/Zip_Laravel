Override print preview
