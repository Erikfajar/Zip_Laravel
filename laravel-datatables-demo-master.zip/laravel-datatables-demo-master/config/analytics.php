<?php

return [

    'enabled' => env('GA_ENABLED', false),

    'id' => env('GA_ID'),

];
